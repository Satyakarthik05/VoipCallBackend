package com.example.VoipCall;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VoipCallApplicationTests {

	@Test
	void contextLoads() {
	}

}
