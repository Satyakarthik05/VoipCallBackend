package com.example.VoipCall;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.socket.config.annotation.*;

@Configuration
@EnableWebSocket
public class WebSocketConfig implements WebSocketConfigurer {
    @Override
    public void registerWebSocketHandlers(WebSocketHandlerRegistry registry) {
        System.out.println("Registering WebSocket handler on /signal");
        registry.addHandler(new SignalingHandler(), "/signal")
                .setAllowedOriginPatterns("*");  // Use this instead of setAllowedOrigins("*") in Spring Boot 2.4+
    }
}
