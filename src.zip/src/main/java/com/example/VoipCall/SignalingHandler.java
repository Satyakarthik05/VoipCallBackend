package com.example.VoipCall;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.socket.*;
import org.springframework.web.socket.handler.TextWebSocketHandler;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class SignalingHandler extends TextWebSocketHandler {
    private final Map<String, WebSocketSession> users = new ConcurrentHashMap<>();
    private static final Logger logger = LoggerFactory.getLogger(SignalingHandler.class);

    @Override
    public void afterConnectionEstablished(WebSocketSession session) throws Exception {
        logger.info("WebSocket connection established: {}", session.getId());
    }

    @Override
    public void handleTextMessage(WebSocketSession session, TextMessage message) {
        String payload = message.getPayload();
        logger.info("Received message: {}", payload);

        try {
            JSONObject json = new JSONObject(payload);
            String type = json.getString("type");

            switch (type) {
                case "join":
                    String userId = json.getString("userId");
                    users.put(userId, session);
                    logger.info("User joined: {}", userId);
                    break;

                case "offer":
                case "answer":
                case "candidate":
                    String targetId = json.getString("target");
                    WebSocketSession targetSession = users.get(targetId);
                    if (targetSession != null && targetSession.isOpen()) {
                        targetSession.sendMessage(new TextMessage(payload));
                        logger.info("Forwarded '{}' message from {} to {}", type, json.optString("userId", "unknown"), targetId);
                    } else {
                        logger.warn("Target user {} not found or session is closed", targetId);
                    }
                    break;

                default:
                    logger.warn("Unknown message type: {}", type);
            }

        } catch (Exception e) {
            logger.error("Error processing message", e);
        }
    }

    @Override
    public void afterConnectionClosed(WebSocketSession session, CloseStatus status) {
        users.entrySet().removeIf(entry -> entry.getValue().equals(session));
        logger.info("Connection closed. Remaining users: {}", users.keySet());
    }
}
