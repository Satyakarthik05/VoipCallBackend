const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const cors = require('cors');

const app = express();
app.use(cors());

const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

// Store connected users
const users = new Map();

// Handle WebSocket connections
wss.on('connection', (ws) => {
  console.log('New client connected');

  ws.on('message', (message) => {
    const data = JSON.parse(message);
    handleSignalingData(ws, data);
  });

  ws.on('close', () => {
    console.log('Client disconnected');
    // Remove user from the map when they disconnect
    users.forEach((value, key) => {
      if (value === ws) {
        users.delete(key);
        console.log(`User ${key} removed`);
      }
    });
  });
});

function handleSignalingData(ws, data) {
  switch (data.type) {
    case 'login':
      handleLogin(ws, data);
      break;
    case 'offer':
      handleOffer(data);
      break;
    case 'answer':
      handleAnswer(data);
      break;
    case 'candidate':
      handleCandidate(data);
      break;
    case 'leave':
      handleLeave(data);
      break;
    default:
      console.log('Unknown message type:', data.type);
  }
}

function handleLogin(ws, data) {
  const { userId } = data;
  
  if (users.has(userId)) {
    sendTo(ws, {
      type: 'login',
      success: false,
      message: 'User ID already taken'
    });
    return;
  }

  users.set(userId, ws);
  ws.userId = userId;

  sendTo(ws, {
    type: 'login',
    success: true,
    users: Array.from(users.keys())
  });

  // Notify all users about the new user
  broadcast({
    type: 'updateUsers',
    users: Array.from(users.keys())
  }, ws);
}

function handleOffer(data) {
  const { otherUserId, offer } = data;
  const targetUser = users.get(otherUserId);

  if (targetUser) {
    sendTo(targetUser, {
      type: 'offer',
      offer,
      otherUserId: data.userId
    });
  }
}

function handleAnswer(data) {
  const { otherUserId, answer } = data;
  const targetUser = users.get(otherUserId);

  if (targetUser) {
    sendTo(targetUser, {
      type: 'answer',
      answer,
      otherUserId: data.userId
    });
  }
}

function handleCandidate(data) {
  const { otherUserId, candidate } = data;
  const targetUser = users.get(otherUserId);

  if (targetUser) {
    sendTo(targetUser, {
      type: 'candidate',
      candidate,
      otherUserId: data.userId
    });
  }
}

function handleLeave(data) {
  const { otherUserId } = data;
  const targetUser = users.get(otherUserId);

  if (targetUser) {
    sendTo(targetUser, {
      type: 'leave',
      otherUserId: data.userId
    });
  }
}

function sendTo(connection, message) {
  if (connection.readyState === WebSocket.OPEN) {
    connection.send(JSON.stringify(message));
  }
}

function broadcast(message, exclude) {
  users.forEach((ws) => {
    if (ws !== exclude && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify(message));
    }
  });
}

// Start the server
const PORT = process.env.PORT || 8080;
server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});